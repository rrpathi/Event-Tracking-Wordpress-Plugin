<?php 
	echo "THis is Comments Page";
 ?>
